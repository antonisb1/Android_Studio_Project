package com.example.new_ergasia;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity_R2 extends AppCompatActivity {

    private String pwd;
    private String name;
    private String cost;
    private String desc;
    private String phy;
    private android.widget.Button Button;

    private final String myIP=new GetIp().getIp();




    boolean elegxos1 = false; //για να μην μπορει να δημιουργει κενη
    boolean elegxos2 = false; // παροχη χωρις να συμπληρωσει τα πεδια
    boolean elegxos3 = false;
    boolean elegxos4 = false;

    boolean elegxos5 = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main_r2);
    }

    //onclick na ginetai keno gia na grapso
    public void onClickErasePwd (View view){
        Button = (Button) findViewById(R.id.button);
        TextView pwd = findViewById(R.id.pwdTxtR2);
        pwd.setText("");
        elegxos1 = true;
        if (elegxos1 && elegxos2 && elegxos3 && elegxos4 && elegxos5) {
            Button = (Button) findViewById(R.id.button);
            Button.setVisibility(View.VISIBLE);
        }

    }
    public void onClickEraseUser (View view){
        Button = (Button) findViewById(R.id.button);
        TextView name = findViewById(R.id.userTxtR2);
        name.setText("");
        elegxos2 = true;
        if (elegxos1 && elegxos2 && elegxos3 && elegxos4 && elegxos5) {
            Button = (Button) findViewById(R.id.button);
            Button.setVisibility(View.VISIBLE);
        }
    }
    public void onClickEraseCost (View view){
        Button = (Button) findViewById(R.id.button);
        TextView cost = findViewById(R.id.costTxtR2);
        cost.setText("");
        elegxos3 = true;
        if (elegxos1 && elegxos2 && elegxos3 && elegxos4 && elegxos5) {
            Button = (Button) findViewById(R.id.button);
            Button.setVisibility(View.VISIBLE);
        }

    }
    public void onClickEraseDisc (View view){
        Button = (Button) findViewById(R.id.button);
        TextView desc = findViewById(R.id.descriptionTxtR2);
        desc.setText("");
        elegxos4 = true;
        if (elegxos1 && elegxos2 && elegxos3 && elegxos4 && elegxos5) {
            Button = (Button) findViewById(R.id.button);
            Button.setVisibility(View.VISIBLE);
        }


    }

    public void onClickErasePhysio (View view) {
        Button = (Button) findViewById(R.id.button);
        TextView physio = findViewById(R.id.physioTxtR2);
        physio.setText("");
        elegxos5 = true;
        if (elegxos1 && elegxos2 && elegxos3 && elegxos4 && elegxos5) {
            Button = (Button) findViewById(R.id.button);
            Button.setVisibility(View.VISIBLE);
        }
    }
    public void onClickButton(View view) {

        TextView pwdTxt = findViewById(R.id.pwdTxtR2);
        TextView nameTxt = findViewById(R.id.userTxtR2);
        TextView costTxt = findViewById(R.id.costTxtR2);
        TextView descTxt = findViewById(R.id.descriptionTxtR2);
        TextView phyTxt = findViewById(R.id.physioTxtR2);

        if (TextUtils.isEmpty(pwdTxt.getText().toString()) || TextUtils.isEmpty(nameTxt.getText().toString())
                ||TextUtils.isEmpty(costTxt.getText().toString()) || TextUtils.isEmpty(descTxt.getText().toString())
                ||TextUtils.isEmpty(phyTxt.getText().toString())) {

            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity_R2.this);
            builder.setCancelable(true);
            builder.setTitle("Προσοχή!");
            builder.setMessage("Συμπληρώστε σωστά τα στοιχεία");
            builder.show();

        } else {

            pwd = pwdTxt.getText().toString();
            name = nameTxt.getText().toString();
            cost = costTxt.getText().toString();
            desc = descTxt.getText().toString();
            phy = phyTxt.getText().toString();

            OkHttpHandler ok = new OkHttpHandler();
            String url = "http://" + myIP + "/PhysioDB/addService.php" + "?password=" + pwd + "&name=" +
                    name + "&cost=" + cost + "&description=" + desc + "&Center=" + phy;
            try {
                ok.addService(url);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }


            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity_R2.this);
            builder.setCancelable(true);
            builder.setTitle("Παροχή");
            builder.setMessage("δημιουργήθηκε");
            builder.show();
        }
    }
}