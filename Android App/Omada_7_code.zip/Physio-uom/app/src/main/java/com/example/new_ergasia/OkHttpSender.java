package com.example.new_ergasia;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class OkHttpSender {

    public OkHttpSender(String myIp,String anId,String aDate) {
        OkHttpClient client = new OkHttpClient();

        // Create an instance of the FormBody.Builder
        FormBody.Builder formBuilder = new FormBody.Builder()
                .add("anID", "0"); // Add any necessary parameters


        RequestBody requestBody = formBuilder.build();

        // Create the HTTP request
        Request request = new Request.Builder()
                .url("http://"+myIp+"/PhysioDB/dtabaseUpdate.php?id="+anId+"&date="+aDate) // Replace with your PHP file's URL
                .post(requestBody)
                .build();

        // Send the HTTP request and handle the response
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                // Handle the response here
                String responseData = response.body().string();
                // Process the response data as needed
            }

            @Override
            public void onFailure(Call call, IOException e) {
                // Handle the failure here
            }
        });
    }
}
