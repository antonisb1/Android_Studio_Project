package com.example.new_ergasia;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class UpdateAppointmentTask extends AsyncTask<String, Void, String> {

    private static final String TAG = "UpdateAppointmentTask";
    private UpdateAppointmentListener listener;

    public UpdateAppointmentTask(UpdateAppointmentListener listener) {
        this.listener = listener;
    }

    @Override
    protected String doInBackground(String... params) {
        String result = "";
        String doctorName = params[0];
        String date = params[1];
        String hour = params[2];
        String available = params[3];
        String appointmentRequest = params[4];
        String patientName = params[5];
        String appointmentDescription = params[6];
        String cost = params[7];

        try {
            String urlParameters = "doctorName=" + URLEncoder.encode(doctorName, "UTF-8") +
                    "&date=" + URLEncoder.encode(date, "UTF-8") +
                    "&hour=" + URLEncoder.encode(hour, "UTF-8") +
                    "&available=" + URLEncoder.encode(available, "UTF-8") +
                    "&appointmentRequest=" + URLEncoder.encode(appointmentRequest, "UTF-8") +
                    "&patientName=" + URLEncoder.encode(patientName, "UTF-8") +
                    "&appointmentDescription=" + URLEncoder.encode(appointmentDescription, "UTF-8") +
                    "&cost=" + URLEncoder.encode(cost, "UTF-8");

            URL url = new URL("http://your_domain.com/update_appointment.php"); // Replace with the actual URL of your PHP file

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setReadTimeout(10000);
            conn.setConnectTimeout(15000);

            OutputStream outputStream = conn.getOutputStream();
            outputStream.write(urlParameters.getBytes("UTF-8"));
            outputStream.flush();
            outputStream.close();

            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                InputStream inputStream = conn.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    result += line;
                }
                bufferedReader.close();
            } else {
                result = "Error updating appointment. Response code: " + responseCode;
            }

            conn.disconnect();
        } catch (IOException e) {
            Log.e(TAG, "Exception: " + e.getMessage());
            result = "Failed to update appointment. Please check your internet connection.";
        }

        return result;
    }

    @Override
    protected void onPostExecute(String result) {
        if (listener != null) {
            listener.onUpdateAppointmentComplete(result);
        }
    }

    public interface UpdateAppointmentListener {
        void onUpdateAppointmentComplete(String result);
    }
}
