package com.example.new_ergasia;

public class GetIp {
    private String ip="192.168.1.12";

    public String getIp() {
        return ip;
    }
}
