package com.example.new_ergasia;

import java.util.ArrayList;

public class AppointMentList_R7 {
    private ArrayList<Appointment_R7> appointmentlist = new ArrayList<>();
    private String date;


    public AppointMentList_R7(String ip,String aDate){
        date = aDate;
        String url= "http://"+ip+"/PhysioDB/apointments.php?date="+date.toString();

        try {
            OkHttpHandler okHttpHandler = new OkHttpHandler();
            appointmentlist = okHttpHandler.populateDropDown(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void printData(){
        for(Appointment_R7 ap: appointmentlist){
            System.out.println(ap.getAppointmentAvailable());
            System.out.println(ap.getAppointmentReq());
            System.out.println(ap.getPatientName());
            System.out.println(ap.getDate());
            System.out.println(ap.getAppointmentAvailable());
            System.out.println(ap.getHour());
            System.out.println(ap.getId());
        }
    }
    public ArrayList<Appointment_R7> getList(){
        return appointmentlist;
    }

}
