package com.example.new_ergasia;

public class Appointment_R7 {
    private String id;
    private String date;
    private String hour;
    private String patientName;
    private String appointmentAvailable;
    private String appointmentReq;
    private String service;
    private boolean checked;


//constructor

    public Appointment_R7(String anId, String aDate, String aHour, String aPatientName, String anAppointmentAvailable, String anAppointmentReq, String aService) {
        id = anId;
        date = aDate;
        hour = aHour;
        patientName = aPatientName;
        appointmentAvailable = anAppointmentAvailable;
        appointmentReq = anAppointmentReq;
        service = aService;
        checked = false;
    }

    public String getId() {
        return id;
    }

    public String getDate() {
        return date;
    }

    public String getHour() {
        return hour;
    }

    public String getPatientName() {
        return patientName;
    }



    public String getAppointmentAvailable() {
        return appointmentAvailable;
    }

    public String getAppointmentReq() {
        return appointmentReq;
    }

    public String getService() {
        return service;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    public boolean isChecked() {
        return checked;
    }
}
