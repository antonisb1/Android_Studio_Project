package com.example.new_ergasia;

import android.os.*;
import org.json.*;

import java.io.IOException;
import java.util.*;
import okhttp3.*;
public class OkHttpHandler {
    public OkHttpHandler() {
        StrictMode.ThreadPolicy policy = new
                StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
    }
    ArrayList<String> getAdmininfo(String url) throws Exception {
        ArrayList<String> Admin = new ArrayList<String>();
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("",
                MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST",
                body).build();
        Response response = client.newCall(request).execute();
        String data = response.body().string();
        //System.out.println("My Response: " + data);
        try {
//            JSONObject json = new JSONObject(data);
//            Iterator<String> keys = json.keys();
//            while(keys.hasNext()) {
//                String name = keys.next();
//                String pass = json.get(name).toString();
//                Admin.add(name);
//                Admin.add(pass);
                JSONArray jsonArray = new JSONArray(data);//To ekana JSONArray giati san Object moy evgaze error kai den ta epairne
                for (int i=0; i<jsonArray.length();i++){
                    Admin.add(jsonArray.getJSONArray(i).getString(0));//Pairnw ta 2 prwta stoixeia toy pinaka
                    Admin.add(jsonArray.getJSONArray(i).getString(1));

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return Admin;
    }
    public void logHistory(String url) throws Exception {
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("",
                MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST",
                body).build();
        Response response = client.newCall(request).execute();
        System.out.println("My Response: " + response);
    }

    public ArrayList<Client> getClient(String url) throws Exception {

        ArrayList<Client> clientList = new ArrayList<Client>();
        OkHttpClient client = new OkHttpClient().newBuilder().build();

        // Set up the HTTP request
        RequestBody body = RequestBody.create("", MediaType.parse("text/plain"));


        Request request = new Request.Builder().url(url).method("POST", body).build();
        Response response = client.newCall(request).execute();

        String data = response.body().string();


        String name = "";
        String password = "";
        String myDoctor = "";
        try {
            JSONArray jsonArray = new JSONArray(data);
            for (int i=0; i<jsonArray.length();i++){
                name = jsonArray.getJSONArray(i).getString(0);
                password =jsonArray.getJSONArray(i).getString(1);
                myDoctor =jsonArray.getJSONArray(i).getString(2);
                Client newClient = new Client(name, password,myDoctor);
                clientList.add(newClient);
            }

            // Now the clientList contains the converted objects
            // You can use the clientList as needed
        } catch (JSONException e) {
            e.printStackTrace();
        }


        return clientList;

    }





    public ArrayList<Appointments> getAppointments(String url) throws Exception {
        ArrayList<Appointments> appointmentsList = new ArrayList<>();
        OkHttpClient client = new OkHttpClient().newBuilder().build();

        RequestBody body = RequestBody.create("", MediaType.parse("text/plain"));

        Request request = new Request.Builder()
                .url(url)
                .method("POST", body)
                .build();

        Response response = client.newCall(request).execute();
        String data = response.body().string();
int cost =0;
        try {
            JSONArray jsonArray = new JSONArray(data);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONArray appointmentArray = jsonArray.getJSONArray(i);

                String id = appointmentArray.getString(0);
                String doctorName = appointmentArray.getString(1);
                String date = appointmentArray.getString(2);
                String hour = appointmentArray.getString(3);
                String available = appointmentArray.getString(4);
                String appointmentRequest = appointmentArray.getString(5);
                String patientName = appointmentArray.getString(6);
                String appointmentDescription = appointmentArray.getString(7);
                //int cost = appointmentArray.getInt(8);

                Appointments newAppointment = new Appointments(id, doctorName, date, hour, available,
                        appointmentRequest, patientName, appointmentDescription, cost);
                appointmentsList.add(newAppointment);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return appointmentsList;
    }






    ArrayList<String> getListofPhysio_R1(String url) throws Exception {
        ArrayList<String> list_Physio = new ArrayList<String>();
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("",
                MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST",
                body).build();
        Response response = client.newCall(request).execute();
        String data = response.body().string();
        //System.out.println("My Response: " + data);
        try {

            JSONArray jsonArray = new JSONArray(data);//To ekana JSONArray giati san Object moy evgaze error kai den ta epairne

            for (int i=0; i<jsonArray.length();i++){
                JSONArray innerJsonArray = jsonArray.getJSONArray(i);//Epeidh exei pinaka mesa se pinaka to kanw etsi
                for (int j=0; j<innerJsonArray.length(); j++){
                    list_Physio.add(innerJsonArray.getString(j));
                    //System.out.println(innerJsonArray.getString(j));
                }

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        //System.out.println(list_Physio);
        return list_Physio;
    }

    public void addService(String url) throws Exception {
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("",
                MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST",
                body).build();
        Response response = client.newCall(request).execute();

    }

    ArrayList<Appointment_R7> populateDropDown(String url) throws Exception {
        ArrayList<Appointment_R7> cbList = new ArrayList<>();
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("",
                MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST",body).build();
        Response response = client.newCall(request).execute();
        String data = response.body().string();
        System.out.println("My Response: " + data);

        try {
            JSONObject json = new JSONObject(data);
            Iterator<String> keys = json.keys();
            while(keys.hasNext()) {
                String id = keys.next();
                String date = json.getJSONObject(id).getString("date").toString();
                String hour = json.getJSONObject(id).getString("hour").toString();
                String available = json.getJSONObject(id).getString("available").toString();
                String appointmentRequest = json.getJSONObject(id).getString("appointmentRequest").toString();
                String patientName = json.getJSONObject(id).getString("patientName").toString();
                String appointmentDescription = json.getJSONObject(id).getString("appointmentDescription").toString();

                cbList.add(new Appointment_R7(id,date,hour,patientName,available,appointmentRequest,appointmentDescription));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return cbList;
    }

    ArrayList<PatientSelect> search(String url) throws Exception {
        ArrayList<PatientSelect> cbList = new ArrayList<>();
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("",
                MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST",
                body).build();
        Response response = client.newCall(request).execute();
        String data = response.body().string();
        System.out.println("My Response: " + data);
        try {
            JSONObject json = new JSONObject(data);
            Iterator<String> keys = json.keys();
            while(keys.hasNext()) {
                String username = keys.next();
                String name = json.getJSONObject(username).getString("name").toString();
                String AMKA = json.getJSONObject(username).getString("AMKA").toString();

                cbList.add(new PatientSelect(name, AMKA));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return cbList;
    }

    //Synartisi pou epistrefei true an iparxei idi o asthenis sto systima
    boolean checkPerson(String url, String amka) throws Exception {

        ArrayList<String> dataList = new ArrayList<>();

        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("",
                MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST",
                body).build();
        Response response = client.newCall(request).execute();
        String data = response.body().string();
        //System.out.println("My Response: " + data);
        try {
            JSONArray jsonArray = new JSONArray(data);

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONArray innerArray = jsonArray.getJSONArray(i);
                String amkas = innerArray.getString(0);
                dataList.add(amkas);
            }
//checking if there is already another patient with that amka
            for (int i = 0; i < dataList.size(); i++) {

                if (dataList.get(i).equals(amka))
                {
                    return true;
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return false;
    }
    //Sinartisi pou eisagei enan astheni sto systima
    public void addPatient_r3(String url) throws Exception {
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("",
                MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST",
                body).build();
        Response response = client.newCall(request).execute();
        System.out.println("My Response: " + response);
    }

    //Synartisi gia to login tou giatrou
    public ArrayList<doctor> getDoctor(String url) throws Exception {

        ArrayList<doctor> clientList = new ArrayList<doctor>();
        OkHttpClient client = new OkHttpClient().newBuilder().build();

        // Set up the HTTP request
        RequestBody body = RequestBody.create("", MediaType.parse("text/plain"));


        Request request = new Request.Builder().url(url).method("POST", body).build();
        Response response = client.newCall(request).execute();

        String data = response.body().string();


        String username = "";
        String password = "";
        try {
            JSONArray jsonArray = new JSONArray(data);
            for (int i=0; i<jsonArray.length();i++){
                username = jsonArray.getJSONArray(i).getString(0);
                password =jsonArray.getJSONArray(i).getString(1);
                doctor newDoctor = new doctor(username, password);
                clientList.add(newDoctor);
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }


        return clientList;

    }

    ArrayList<AppointmentsR8> populateDropDown_r8(String url) throws Exception {
        ArrayList<AppointmentsR8> appList = new ArrayList<>();
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        RequestBody body = RequestBody.create("",
                MediaType.parse("text/plain"));
        Request request = new Request.Builder().url(url).method("POST",
                body).build();
        Response response = client.newCall(request).execute();
        String data = response.body().string();
        System.out.println("My Response: " + data);

        try {
            JSONObject json = new JSONObject(data);
            Iterator<String> keys = json.keys();

            while(keys.hasNext()) {
                String id = keys.next();
                String hour = json.getJSONObject(id).getString("hour").toString();
                String patientName = json.getJSONObject(id).getString("patientName").toString();
                String appointmentDescription = json.getJSONObject(id).getString("appointmentDescription").toString();

                appList.add(new AppointmentsR8(id, hour, patientName, appointmentDescription));
            }
        }
        catch (JSONException e) {
            e.printStackTrace();
        }
        return appList;
    }

}
