package com.example.new_ergasia;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;


import java.io.IOException;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;

import android.widget.TextView;
import android.widget.Toast;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.converter.scalars.ScalarsConverterFactory;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class Make_An_Appointment_R9 extends AppCompatActivity {
    private BottomNavigationView bottomNav;
    private int selectedYear;
    private int selectedMonth;
    private int selectedDayOfMonth;
    String finalHour;
    final String myIP = "192.168.1.12";
    String url = "http://" + myIP + "/PhysioDB/appointments.php";
    String fullDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_make_an_appointment_r9);

        //remove ActionBar
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();


        CalendarView calendarView = findViewById(R.id.calendarView);
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                // Update the member variables with the selected date
                selectedYear = year;
                selectedMonth = month + 1;
                selectedDayOfMonth = dayOfMonth;
                fullDate = selectedYear + "-" + String.format("%02d", selectedMonth) + "-" + String.format("%02d", selectedDayOfMonth);


                ArrayList<Appointments> appointmentsList = new ArrayList<Appointments>();
                TextView hour = null;
                int k1 = 0;
                int textViewId;

                try {
                    OkHttpHandler okHttpHandler = new OkHttpHandler();
                    appointmentsList = okHttpHandler.getAppointments(url);

                    boolean dateFound = false; // Flag to track if the date is found

                    for (Appointments a : appointmentsList) {
                         if (fullDate.equals(a.date)) {
                            k1++;
                            textViewId = getResources().getIdentifier("firstHour" + k1, "id", getPackageName());
                            hour = findViewById(textViewId);
                            hour.setText(a.hour);
                            hour.setGravity(Gravity.CENTER);
                            hour.setTypeface(null, Typeface.BOLD);
                            dateFound = true; // Set the flag to true since the date is found
                        }
                        if (k1 == 5) {
                            break;
                        }
                    }

                    if (!dateFound) {
                        // Clear the TextViews or perform any other desired action
                        for (int i = 1; i <= 4; i++) {
                            textViewId = getResources().getIdentifier("firstHour" + i, "id", getPackageName());
                            hour = findViewById(textViewId);
                            hour.setText("");
                        }
                        ErrorDialogFragment dialogFragment = new ErrorDialogFragment();
                        dialogFragment.setHeader("Not found");
                        dialogFragment.setMessage("There are no available time slots for the selected date you are trying to visit.");

                        // Show the dialog
                        dialogFragment.show(getSupportFragmentManager(), "warning_dialog");
                    }
                } catch (Exception e) {
                    // Handle exceptions
                }

                TextView t1 = findViewById(R.id.firstHour1);
                TextView t2 = findViewById(R.id.firstHour2);
                TextView t3 = findViewById(R.id.firstHour3);
                TextView t4 = findViewById(R.id.firstHour4);

                String textV1 = t1.getText().toString();
                String textV2 = t2.getText().toString();
                String textV3 = t3.getText().toString();
                String textV4 = t4.getText().toString();
                final Drawable defaultBackground = t1.getBackground().mutate(); // Get the default background drawable

                t1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        t1.setBackgroundColor(Color.RED);
                        t2.setBackground(defaultBackground);
                        t3.setBackground(defaultBackground);
                        t4.setBackground(defaultBackground);
                        finalHour = t1.getText().toString();
                     }
                });

                t2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        t2.setBackgroundColor(Color.RED);
                        t1.setBackground(defaultBackground);
                        t3.setBackground(defaultBackground);
                        t4.setBackground(defaultBackground);
                        finalHour = t2.getText().toString();
                     }
                });
                t3.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        t3.setBackgroundColor(Color.RED);
                        t2.setBackground(defaultBackground);
                        t1.setBackground(defaultBackground);
                        t4.setBackground(defaultBackground);
                        finalHour = t3.getText().toString();

                    }
                });

                t4.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        t4.setBackgroundColor(Color.RED);
                        t1.setBackground(defaultBackground);
                        t3.setBackground(defaultBackground);
                        t2.setBackground(defaultBackground);
                        finalHour = t4.getText().toString();
                     }
                });


            }
        });


        Button finalButton = findViewById(R.id.select_hour_button);
          finalButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Login_R9 patientName = new Login_R9();


                OkHttpClient client = new OkHttpClient().newBuilder().build();
                // Set up the HTTP request
                RequestBody body = RequestBody.create("", MediaType.parse("text/plain"));
                Request request = new Request.Builder().url(url).method("POST", body).build();
                Response response = null;
                try {
                    response = client.newCall(request).execute();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

                String data = null;
                try {
                    response = client.newCall(request).execute();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

                 try {
                    data = response.body().string();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }


                     String appointmentRequest ="";

                    String appointmentDescription = "";
                    String id = "";
                    String available="" ;

                String url2;

                Login_R9 loginR9 = new Login_R9();


                try {
                    JSONArray jsonArray = new JSONArray(data);
                    for (int i = 0; i < jsonArray.length(); i++) {

                        if (fullDate.equals(jsonArray.getJSONArray(i).getString(2)) && finalHour.equals(jsonArray.getJSONArray(i).getString(3))) {
                                id=jsonArray.getJSONArray(i).getString(0);
//edw allagh
                                 appointmentRequest="1";
                                url2 = "http://"+myIP+"/PhysioDB/update_appointment.php?appointmentRequest=" + appointmentRequest +
                                    "&patientName=" + Login_R9.nameGiven + "&appointmentDescription=" + appointmentDescription + "&id=" + id ;

                            try {
                                OkHttpHandler okHttpHandler = new OkHttpHandler();
                                okHttpHandler.logHistory(url2);
                                Toast.makeText(getApplicationContext(), "Selection Logged",
                                        Toast.LENGTH_SHORT).show();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }


                            try {
                                OkHttpHandler okHttpHandler = new OkHttpHandler();
                                okHttpHandler.logHistory(url2);
                                Toast.makeText(getApplicationContext(), "Selection Logged",
                                        Toast.LENGTH_SHORT).show();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }


                        }
                    }
                } catch (Exception e) {
                    Log.e("Fail 1", e.toString());
                    e.printStackTrace();
                }




                // Create an instance of SuccessDialogFragment
                ErrorDialogFragment dialogFragment = new ErrorDialogFragment();
                dialogFragment.setHeader("Success");
                dialogFragment.setMessage("Your appointment has been sent, we will contact you as soon as possible! ");

// Show the dialog
                dialogFragment.show(getSupportFragmentManager(), "success_dialog");


            }
        });

        bottomNav = findViewById(R.id.BottomNav);
        bottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.home:
                        Intent intent = new Intent(Make_An_Appointment_R9.this, MainActivity_R1.class);
                        startActivity(intent);
                        finish();
                        return true;
                    case R.id.help:
                        // Handle dashboard button click
                        return true;
                    case R.id.back:
                        Intent intent2 = new Intent(Make_An_Appointment_R9.this, User_Activity_R9.class);
                        startActivity(intent2);
                        finish();
                        return true;
                    default:
                        return false;
                }
            }


        });

    }

}












