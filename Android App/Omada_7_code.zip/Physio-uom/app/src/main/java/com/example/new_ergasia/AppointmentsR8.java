package com.example.new_ergasia;

public class AppointmentsR8 {

    private String id;
    private String hour;
    private String name;
    private String description;

    public AppointmentsR8(String id, String hour, String name, String description) {
        this.id = id;
        this.hour = hour;
        this.name = name;
        this.description = description;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getHour() {
        return hour;
    }

    public void setHour(String hour) {
        this.hour = hour;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
