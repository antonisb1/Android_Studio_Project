package com.example.new_ergasia;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity_R8 extends AppCompatActivity {

    private final String myIP = new GetIp().getIp();
    private AppointmentListR8 appList;
    private ArrayList<AppointmentsR8> appointmentslist;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_r8);

        appList = new AppointmentListR8(myIP,"2023-06-07");
        appointmentslist = appList.getAppointmentsList();

        TextView onoma1R8 = findViewById(R.id.onoma1R8);
        onoma1R8.setText(appointmentslist.get(0).getName());
        TextView perigraphi1R8 = findViewById(R.id.perigraphi1R8);
        perigraphi1R8.setText(appointmentslist.get(0).getDescription());

        TextView onoma2R8 = findViewById(R.id.onoma2R8);
        onoma2R8.setText(appointmentslist.get(1).getName());
        TextView perigraphi2R8 = findViewById(R.id.perigraphi2R8);
        perigraphi2R8.setText(appointmentslist.get(1).getDescription());

        //  System.out.println(appointmentslist.get(0).getId());
    }
}