package com.example.new_ergasia;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Activity_R3 extends AppCompatActivity {

    private BottomNavigationView bottomNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_r3);

        Intent intent = getIntent();
        //the username of the doctor the new patient is going to have
        String doctorName_r3 = intent.getStringExtra("doctorName");
        System.out.println(doctorName_r3);
        //remove ActionBar
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();


        //My ip change
        String myIP = new GetIp().getIp();


        EditText NameText_r3 = findViewById(R.id.name_text);

        NameText_r3.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    NameText_r3.setText("");
                }
            }
        });

        EditText AddressText_r3 = findViewById(R.id.Address_text);

        AddressText_r3.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    AddressText_r3.setText("");
                }
            }
        });
        EditText AMKAText_r3 = findViewById(R.id.amka_text);

        AMKAText_r3.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    AMKAText_r3.setText("");
                }
            }
        });

        Button myCreateButton_r3 = findViewById(R.id.create_button);

        LinearLayout message_layout_r3 = findViewById(R.id.message_layout);
        TextView message_r3 = findViewById(R.id.message_r3);

        myCreateButton_r3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String patient_name_r3 = NameText_r3.getText().toString();
                String patient_address_r3 = AddressText_r3.getText().toString();
                String patient_AMKA_r3 = AMKAText_r3.getText().toString();

                String url_r3_Existing = "http://"+myIP+"/PhysioDB/ExistingCheck.php";

                OkHttpHandler okHttpHandler_r3 = new OkHttpHandler();
                boolean patientAlreadyExists = false;
                try {
                    patientAlreadyExists = okHttpHandler_r3.checkPerson(url_r3_Existing, patient_AMKA_r3);
                    System.out.println(patientAlreadyExists);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                //Εαν εχει δωσει ΑΜΚΑ διαφορετικο μηκος απο 11 αριθμους
                if(patient_AMKA_r3.length() != 11)
                {
                    message_r3.setText("Το ΑΜΚΑ που δώσατε είναι λάθος, δεν αποτελείται απο 11 ψηφία. Εσείς δώσατε " + patient_AMKA_r3.length() +" ψηφία. \n Ένα παράδειγμα AMKA είναι: 12345678910");
                    message_layout_r3.setVisibility(View.VISIBLE);

                }
                //Εαν το αμκα δεν ειναι μονο αριθμοι

                else if(!patient_AMKA_r3.matches("[0-9]+"))
                {
                    message_r3.setText("Το ΑΜΚΑ που δώσατε είναι λάθος, δεν αποτελείται απο μόνο αριθμούς.\n εσείς δώσατε "+ patient_AMKA_r3 + "\n Ένα παράδειγμα AMKA είναι: 12345678910");
                    message_layout_r3.setVisibility(View.VISIBLE);

                }
                //ean den exei gemisi ola ta kelia
                else if(patient_name_r3.isEmpty() || patient_address_r3.isEmpty() || patient_AMKA_r3.isEmpty() )
                {
                    message_r3.setText("Πρέπει να γεμίσετε όλα τα κελιά. \n Για παράδειγμα \nΌνομα: Παπαδάκης Νίκος \n Διεύθυνση: Εγνατίας 45\n AMKA: 12345678910");
                    message_layout_r3.setVisibility(View.VISIBLE);
                }


                //asthenis iparxei sto systima
                else if(patientAlreadyExists)
                {
                    message_r3.setText("Ο ασθενής υπάρχει ήδη στο σύστημα.");
                    message_layout_r3.setVisibility(View.VISIBLE);

                }
                else{

                    //if there is nothing wrong the patient will be admited in the system
                    String url_r3_newPatient = "http://" + myIP + "/PhysioDB/CreatePatient.php?username=" + patient_AMKA_r3 +
                            "&password=" + "1234" + "&name=" + patient_name_r3 + "&address=" + patient_address_r3+ "&AMKA="
                            + patient_AMKA_r3+ "&myDoctor=" + doctorName_r3;
                    try {
                        okHttpHandler_r3.addPatient_r3(url_r3_newPatient);

                        message_r3.setText("Ο ασθενής δημιουργήθηκε με επιτυχία. \n Έχει καταχωρηθεί στο σύστημα με τα εξής στοιχεία: \n Username: "+ patient_AMKA_r3 +"\n Password: 1234" );
                        message_layout_r3.setVisibility(View.VISIBLE);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                }


            }


        });


        //Klisimo message parathiro me to koumpi button_close_r3

        Button button_close_r3 = findViewById(R.id.escape_message_button);

        button_close_r3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                message_layout_r3.setVisibility(View.GONE);
            }
        });

        //Navigation buttons

        bottomNav = findViewById(R.id.BottomNav);
        bottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.home:
                        Intent intent = new Intent(Activity_R3.this, MainActivity_R1.class);
                        startActivity(intent);
                        finish();
                        return true;
                    case R.id.help:
                        ExampleDialog exampleDialog = new ExampleDialog();
                        exampleDialog.show(getSupportFragmentManager(),"example dialog");
                        return true;
                    case R.id.back:
                        onBackPressed();
                        return true;
                    default:
                        return false;
                }
            }


        });

    }
}