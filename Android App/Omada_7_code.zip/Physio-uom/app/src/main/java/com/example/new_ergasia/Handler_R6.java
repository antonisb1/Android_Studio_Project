package com.example.new_ergasia;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Handler_R6 {
    private static final String PHP_URL = "http://192.168.1.12/PhysioDB/r6_getInfo.php";

    private List<String> ids;
    private List<String> doctorNames;
    private List<String> dates;
    private List<String> hours;
    private List<String> availabilities;
    private List<String> appointmentRequests;
    private List<String> patientNames;
    private List<String> appointmentDescriptions;
    private List<String> costs;

    public Handler_R6() {
        ids = new ArrayList<>();
        doctorNames = new ArrayList<>();
        dates = new ArrayList<>();
        hours = new ArrayList<>();
        availabilities = new ArrayList<>();
        appointmentRequests = new ArrayList<>();
        patientNames = new ArrayList<>();
        appointmentDescriptions = new ArrayList<>();
        costs = new ArrayList<>();
        System.out.println("Object Created!");
    }

    public void fetchDataFromPhpFile() {
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder().url(PHP_URL).build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    System.out.println("Connected!");
                    String responseData = response.body().string();
                    // Parse the response data and store it in ArrayLists
                    String[] rows = responseData.split("\n");
                    for (String row : rows) {
                        String[] columns = row.split(",");
                        if (columns.length >= 8) {
                            ids.add(extractValue(columns[0]));
                            doctorNames.add(extractValue(columns[1]));
                            dates.add(extractValue(columns[2]));
                            hours.add(extractValue(columns[3]));
                            availabilities.add(extractValue(columns[4]));
                            appointmentRequests.add(extractValue(columns[5]));
                            patientNames.add(extractValue(columns[6]));
                            appointmentDescriptions.add(extractValue(columns[7]));
                            costs.add(extractValue(columns[8]));
                        }
                    }


                } else {
                    System.out.println("Request failed with code: " + response.code());
                }
            }
        });
    }

    private String extractValue(String data) {
        int colonIndex = data.indexOf(":");
        if (colonIndex != -1) {
            String value = data.substring(colonIndex + 1).trim();
            // Remove "",{ and }
            value = value.replaceAll("[\"{}]", "");
            return value;
        }
        return "";
    }

    public void printData() {
        // Print the retrieved data
        for (int i = 0; i < doctorNames.size(); i++) {
            System.out.println("ID: " + ids.get(i));
            System.out.println("Doctor Name: " + doctorNames.get(i));
            System.out.println("Date: " + dates.get(i));
            System.out.println("Hour: " + hours.get(i));
            System.out.println("Availability: " + availabilities.get(i));
            System.out.println("Appointment Request: " + appointmentRequests.get(i));
            System.out.println("Patient Name: " + patientNames.get(i));
            System.out.println("Appointment Description: " + appointmentDescriptions.get(i));
            System.out.println("Cost: " + costs.get(i));
            System.out.println();
        }
        System.out.println("Finished Printing!");
    }
    public List<String> getDoctorNames() {
        return doctorNames;
    }

    public List<String> getDates() {
        return dates;
    }
    public List<String> getHours() {
        return hours;
    }

    public List<String> getAvailabilities() {
        return availabilities;
    }

    public List<String> getAppointmentRequests() {
        return appointmentRequests;
    }

    public List<String> getPatientNames() {
        return patientNames;
    }

    public List<String> getAppointmentDescriptions() {
        return appointmentDescriptions;
    }

    public List<String> getCosts() {
        return costs;
    }

}
