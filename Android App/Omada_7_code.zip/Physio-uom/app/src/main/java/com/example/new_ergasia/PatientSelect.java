package com.example.new_ergasia;

public class PatientSelect {
    private String name;
    private String AMKA;

    public PatientSelect(String pName, String pAMKA) {
        name = pName;
        AMKA = pAMKA;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getName(){
        return name;
    }
    public String getAMKA() {
        return AMKA;
    }

    public void setAMKA(String AMKA) {
        this.AMKA = AMKA;
    }


}
