package com.example.new_ergasia;

public class Client {
    private String password;
    private String name;

    private String myDoctor;
    // Constructor
    public Client(String name, String password) {
        this.password = password;
        this.name = name;
    }
    public Client(String name, String password,String myDoctor) {
        this.password = password;
        this.name = name;
        this.myDoctor=myDoctor;
    }

    // Getters and setters
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getMyDoctor() {
        return myDoctor;
    }
}

