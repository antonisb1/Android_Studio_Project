package com.example.new_ergasia;

import java.util.ArrayList;

public class AppointmentListR8 {

    private ArrayList<AppointmentsR8> appointmentsList;

    public AppointmentListR8(String ip, String date) {
        String url= "http://"+ip+"/PhysioDB/R8.php?date=" + date;
        try {
            OkHttpHandler okHttpHandler = new OkHttpHandler();
            appointmentsList = okHttpHandler.populateDropDown_r8(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<AppointmentsR8> getAppointmentsList() {
        return appointmentsList;
    }

    public void setAppointmentsList(ArrayList<AppointmentsR8> appointmentsList) {
        this.appointmentsList = appointmentsList;
    }
}
