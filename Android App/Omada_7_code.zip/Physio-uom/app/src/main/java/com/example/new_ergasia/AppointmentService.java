package com.example.new_ergasia;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface AppointmentService {
    @GET("update_appointment.php")
    Call<Void> updateAppointment(
            @Query("id") String id,
            @Query("appointmentRequest") String appointmentRequest,
            @Query("patientName") String patientName,
            @Query("appointmentDescription") String appointmentDescription
    );

}
