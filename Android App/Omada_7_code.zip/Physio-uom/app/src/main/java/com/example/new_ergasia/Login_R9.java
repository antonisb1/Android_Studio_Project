package com.example.new_ergasia;
import java.time.LocalDateTime;
import java.util.Date;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
 import java.time.format.DateTimeFormatter;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class Login_R9 extends AppCompatActivity {
    public static String nameGiven;


    private final String myIP=new GetIp().getIp();
    private ExampleDialog exampleDialog = new ExampleDialog();
    private BottomNavigationView bottomNav;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_r9);
        //remove ActionBar
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        Button login = findViewById(R.id.eisodos_client_button);


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String myIP = "192.168.1.12";
                String url = "http://" + myIP + "/PhysioDB/client_login.php";

                //Pairnw to Text kai to metatrepw se String gia na dw an einai ta idia me thn vash
                TextView TextName = findViewById(R.id.name_client);
                TextView TextPass = findViewById(R.id.client_password);

                  nameGiven = TextName.getText().toString();
                String passGiven = TextPass.getText().toString();


                ArrayList<Client> client_info = new ArrayList<Client>();


                try {
                    OkHttpHandler okHttpHandler = new OkHttpHandler();
                    client_info = okHttpHandler.getClient(url);
                    boolean flag = true;

                    for (Client c : client_info) {
                        if (c.getName().equals(nameGiven) && c.getPassword().equals(passGiven)) {
                            Intent intent = new Intent(Login_R9.this, User_Activity_R9.class);
                            startActivity(intent);
                            flag = false;
                            break;  // Exit the loop if credentials match for any client
                        }
                    }

                    if (flag) {
                        // Create an instance of ErrorDialogFragment
                        ErrorDialogFragment dialogFragment = new ErrorDialogFragment();
                        dialogFragment.setHeader("Wrong Credentials");
                        dialogFragment.setMessage("Please enter the correct username and password");

                        // Show the dialog
                        dialogFragment.show(getSupportFragmentManager(), "error_dialog");
                    }



                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });

        bottomNav = findViewById(R.id.BottomNav);
        bottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.home:
                        Intent intent = new Intent(Login_R9.this, MainActivity_R1.class);
                        startActivity(intent);
                        finish();
                        return true;
                    case R.id.help:
                        exampleDialog.setHeader("Help");
                        exampleDialog.setText("Please give the name and the password to login.");
                        exampleDialog.show(getSupportFragmentManager(),"example dialog");
                        return true;
                    case R.id.back:
                        Intent intent2 = new Intent(Login_R9.this, MainActivity_R1.class);
                        startActivity(intent2);
                        finish();
                    default:
                        return false;
                }
            }


        });



    }
}
