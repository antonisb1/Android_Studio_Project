package com.example.new_ergasia;

import java.util.ArrayList;

public class PatientList {
    private ArrayList<PatientSelect> ptl = new ArrayList<PatientSelect>();

    public PatientList(String ip, String anAmka){
        String url= "http://"+ip+"/PhysioDB/search.php?AMKA="+anAmka;
        try {
            OkHttpHandler okHttpHandler = new OkHttpHandler();
            ptl = okHttpHandler.search(url);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<PatientSelect> getList(){
        return ptl;
    }

}
