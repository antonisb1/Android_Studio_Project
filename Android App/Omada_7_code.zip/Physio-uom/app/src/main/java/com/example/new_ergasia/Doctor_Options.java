package com.example.new_ergasia;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Doctor_Options extends AppCompatActivity {
    private BottomNavigationView bottomNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_options);

        Intent intent = getIntent();
        String doctorName = intent.getStringExtra("doctorName");

        //remove ActionBar
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        TextView OptionR6 = findViewById(R.id.weekly_text_r6);
        OptionR6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent docrotIntent = new Intent(Doctor_Options.this,Appointment_Program_R6.class);
                startActivity(docrotIntent);
            }
        });

        TextView OptionR7 = findViewById(R.id.selection_text_r7);
        OptionR7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent docrotIntent = new Intent(Doctor_Options.this,MainActivity_R7.class);
                startActivity(docrotIntent);
            }
        });


        TextView OptionR5 = findViewById(R.id.selection_text_r5);
        OptionR5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent docrotIntent = new Intent(Doctor_Options.this,MainActivity_R5.class);
                startActivity(docrotIntent);
            }
        });

        TextView OptionR3 = findViewById(R.id.create_patient_r3);
        OptionR3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent docrotIntent = new Intent(Doctor_Options.this,Activity_R3.class);
                docrotIntent.putExtra("doctorName", doctorName);
                startActivity(docrotIntent);
            }
        });

        TextView OptionR8 = findViewById(R.id.selection_text_r8);
        OptionR8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent docrotIntent = new Intent(Doctor_Options.this,MainActivity_R8.class);
                startActivity(docrotIntent);
            }
        });



        bottomNav = findViewById(R.id.BottomNav);
        bottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.home:
                        Intent intent = new Intent(Doctor_Options.this, MainActivity_R1.class);
                        startActivity(intent);
                        finish();
                        return true;
                    case R.id.help:
                        return true;
                    case R.id.back:
                        Intent intent2 = new Intent(Doctor_Options.this, MainActivity_R1.class);
                        startActivity(intent2);
                        finish();
                    default:
                        return false;
                }
            }


        });
    }
}