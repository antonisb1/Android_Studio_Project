package com.example.new_ergasia;

public class Appointments {
    String doctorName;
    String date;
    String hour;
    String available;
    String appointmentRequest;
    String  patientName;
    String appointmentDescription;
    int cost;
    String id;
    public Appointments(String id,String doctorName, String date,String hour, String  appointmentRequest, String available,
                        String  patientName, String appointmentDescription, int cost){

        this.doctorName=doctorName;
        this.date=date;
        this.hour=hour;
        this.available=available;
        this.appointmentRequest=appointmentRequest;
        this.patientName=patientName;
        this.appointmentDescription=appointmentDescription;
        this.cost=cost;
        this.id=id;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public String getDate() {
        return date;
    }
    public String getHour() {
        return hour;
    }

    public String getAvailable() {
        return available;
    }

    public String getAppointmentRequest() {
        return appointmentRequest;
    }

    public String getPatientName() {
        return patientName;
    }

    public String getAppointmentDescription() {
        return appointmentDescription;
    }

    public int getCost() {
        return cost;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setHour(String hour) {
        this.hour = hour;
    }

    public void setAvailable(String available) {
        this.available = available;
    }

    public void setAppointmentRequest(String appointmentRequest) {
        this.appointmentRequest = appointmentRequest;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public void setAppointmentDescription(String appointmentDescription) {
        this.appointmentDescription = appointmentDescription;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }
}
