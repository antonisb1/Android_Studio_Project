package com.example.new_ergasia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity_R5 extends AppCompatActivity {

    private String myIP = new GetIp().getIp();
    private ArrayList<PatientSelect> p1;
    private EditText editText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        PatientList ptl = new PatientList(myIP,"01010101011");
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main_r5);

        Button epilogh = findViewById(R.id.selectionBtn_r5);

        epilogh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity_R5.this,MainActivity_R4.class);
                startActivity(intent);
            }
        });
    }

    public void onClickSearch_r5(View view){
        editText = findViewById(R.id.search_r5);
        String text = editText.getText().toString();
        PatientList ptList = new PatientList(myIP,text);
        p1 = ptList.getList();
        ListView listView = findViewById(R.id.results_r5);
        listView.setVisibility(View.VISIBLE);
        ListView lsView = findViewById(R.id.results_r5);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);

        for(PatientSelect p:p1){
            adapter.add(p.getAMKA());
            adapter.add(p.getName());
            lsView.setAdapter(adapter);
        }

    }
}