package com.example.new_ergasia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class MainActivity_R7 extends AppCompatActivity {

    //ελεγχος για λειτουργεια του πρωτου κουμπιου μονο μια φορα
    private boolean notUsed = true;
    private static int loopCounter = 1;
    private Calendar cal;
    private final String myIP = new GetIp().getIp();






    private ArrayList<Appointment_R7> reqList = new ArrayList<>();
    private ArrayList<Boolean> appointmentChecked = new ArrayList<>();






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();


        setContentView(R.layout.activity_main_r7);


        TextView date = findViewById(R.id.date_R7);

        cal= Calendar.getInstance();
        SimpleDateFormat yearlyFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat dailyFormat = new SimpleDateFormat("EEEE", Locale.getDefault());
        String today = yearlyFormat.format(cal.getTime());

        date.setText(today);
        String dayOfTheWeek = dailyFormat.format(cal.getTime());

        AppointMentList_R7 ap1 = new AppointMentList_R7(myIP,today);
        reqList = ap1.getList();


        //λιστα με μέρες για spinner
        List<String> spinnerArray =  new ArrayList<>();

        if (dayOfTheWeek.equals("Monday")) {
            spinnerArray.add("Δευτέρα ");

        }else if (dayOfTheWeek.equals("Tuesday")){
            spinnerArray.add("Τρίτη");

        }else if (dayOfTheWeek.equals("Wednesday")){
            spinnerArray.add("Τετάρτη");
        }else if (dayOfTheWeek.equals("Thursday")){
            spinnerArray.add("Πέμπτη");

        }else if (dayOfTheWeek.equals("Friday")){
            spinnerArray.add("Παρασκευή");

        }else if (dayOfTheWeek.equals("Saturday")){
            spinnerArray.add("Σάββατο");
        }else if(dayOfTheWeek.equals("Sunday")){
            spinnerArray.add("Κυριακή");
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, spinnerArray);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner sItems =findViewById(R.id.daySelector_r7);
        sItems.setAdapter(adapter);




    }

    public void onClickNext(View view){
        TableRow SecondRow = findViewById(R.id.SecondRow_R7);

        TextView nameRow2 = findViewById(R.id.patientNameSecondRow_R7);
        TextView wantedTimeRow2 = findViewById(R.id.wantedTimeSecondRow_R7);
        TextView serviceRow2 = findViewById(R.id.serviceSecondRow_R7);
        CheckBox checkBox2 = findViewById(R.id.checkBoxSecondRow_R7);

        TableRow ThirdRow = findViewById(R.id.ThirdRow_R7);

        TextView nameRow3 = findViewById(R.id.patientNameThirdRow_R7);
        TextView wantedTimeRow3 = findViewById(R.id.wantedTimeThirdRow_R7);
        TextView serviceRow3 = findViewById(R.id.serviceThirdRow_R7);
        CheckBox checkBox3 = findViewById(R.id.checkBoxThirdRow_R7);

        TableRow ForthRow = findViewById(R.id.ForthRow_R7);


        TextView nameRow4 = findViewById(R.id.patientNameForthRow_R7);
        TextView wantedTimeRow4 = findViewById(R.id.wantedTimeForthRow_R7);
        TextView serviceRow4 = findViewById(R.id.serviceForthRow_R7);
        CheckBox checkBox4 = findViewById(R.id.checkBoxForthRow_R7);
        Button next = findViewById(R.id.nextButton);


        int listSize = reqList.size();


        if (ForthRow.getVisibility() ==  View.VISIBLE){
            appointmentChecked.add(checkBox2.isChecked());
            checkBox2.setChecked(false);

            appointmentChecked.add(checkBox3.isChecked());
            checkBox3.setChecked(false);

            appointmentChecked.add(checkBox4.isChecked());
            checkBox4.setChecked(false);
        }
        else if (ThirdRow.getVisibility() ==  View.VISIBLE){
            appointmentChecked.add(checkBox2.isChecked());
            checkBox2.setChecked(false);

            appointmentChecked.add(checkBox3.isChecked());
            checkBox3.setChecked(false);
        }else if (SecondRow.getVisibility() ==  View.VISIBLE){
            appointmentChecked.add(checkBox2.isChecked());
            checkBox2.setChecked(false);
        }

        if(listSize-loopCounter > 3){
            loopCounter +=3;

        } else if (listSize-loopCounter <=3) {


            loopCounter = loopCounter +(listSize - loopCounter);
        }

        if (loopCounter <= listSize){
            if(loopCounter%3 == 1){
                SecondRow.setVisibility(View.VISIBLE);
                ThirdRow.setVisibility(View.INVISIBLE);
                ForthRow.setVisibility(View.INVISIBLE);


                nameRow2.setText(reqList.get(loopCounter-1).getPatientName());
                wantedTimeRow2.setText(reqList.get(loopCounter-1).getHour());
                serviceRow2.setText(reqList.get(loopCounter-1).getService());

                loopCounter = listSize;
            }
            else if(loopCounter%3 == 2){

                SecondRow.setVisibility(View.VISIBLE);
                ThirdRow.setVisibility(View.VISIBLE);
                ForthRow.setVisibility(View.INVISIBLE);


                nameRow2.setText(reqList.get(loopCounter - 2).getPatientName());
                wantedTimeRow2.setText(reqList.get(loopCounter - 2).getHour());
                serviceRow2.setText(reqList.get(loopCounter - 2).getService());




                nameRow3.setText(reqList.get(loopCounter - 1).getPatientName());
                wantedTimeRow3.setText(reqList.get(loopCounter - 1).getHour());
                serviceRow3.setText(reqList.get(loopCounter - 1).getService());

                loopCounter = listSize;
            }

            else if(loopCounter%3 == 0){

                SecondRow.setVisibility(View.VISIBLE);
                ThirdRow.setVisibility(View.VISIBLE);
                ForthRow.setVisibility(View.VISIBLE);

                nameRow2.setText(reqList.get(loopCounter - 3).getPatientName());
                wantedTimeRow2.setText(reqList.get(loopCounter - 3).getHour());
                serviceRow2.setText(reqList.get(loopCounter - 3).getService());




                nameRow3.setText(reqList.get(loopCounter - 2).getPatientName());
                wantedTimeRow3.setText(reqList.get(loopCounter - 2).getHour());
                serviceRow3.setText(reqList.get(loopCounter - 2).getService());




                nameRow4.setText(reqList.get(loopCounter - 1).getPatientName());
                wantedTimeRow4.setText(reqList.get(loopCounter - 1).getHour());
                serviceRow4.setText(reqList.get(loopCounter - 1).getService());



            }
        }

        if(loopCounter >= reqList.size() ) {
            next.setVisibility(View.INVISIBLE);

            Button submit = findViewById(R.id.finalizeButton_r7);
            submit.setVisibility(View.VISIBLE);
        }

    }

    public void onClickVisibility(View view){


        if(notUsed){



            TableLayout tb = findViewById(R.id.DataPrint_R7);
            tb.setVisibility(View.VISIBLE);



            TableRow SecondRow = findViewById(R.id.SecondRow_R7);

            TextView nameRow2 = findViewById(R.id.patientNameSecondRow_R7);
            TextView wantedTimeRow2 = findViewById(R.id.wantedTimeSecondRow_R7);
            TextView serviceRow2 = findViewById(R.id.serviceSecondRow_R7);



            TableRow ThirdRow = findViewById(R.id.ThirdRow_R7);


            TextView nameRow3 = findViewById(R.id.patientNameThirdRow_R7);
            TextView wantedTimeRow3 = findViewById(R.id.wantedTimeThirdRow_R7);
            TextView serviceRow3 = findViewById(R.id.serviceThirdRow_R7);


            TableRow ForthRow = findViewById(R.id.ForthRow_R7);

            TextView nameRow4 = findViewById(R.id.patientNameForthRow_R7);
            TextView wantedTimeRow4 = findViewById(R.id.wantedTimeForthRow_R7);
            TextView serviceRow4 = findViewById(R.id.serviceForthRow_R7);


            TextView date = findViewById(R.id.date_R7);



            cal= Calendar.getInstance();
            SimpleDateFormat yearlyFormat = new SimpleDateFormat("yyyy-MM-dd");
            String today = yearlyFormat.format(cal.getTime());//σημερινή μερα ημμερομηνια

            date.setText(today);






            //αριθμος επαναληψεων και μεγεθος λίστας

            loopCounter = reqList.size();//μέγεθος της λιστας

            if(loopCounter == 1){
                SecondRow.setVisibility(View.VISIBLE);


                nameRow2.setText(reqList.get(0).getPatientName());
                wantedTimeRow2.setText(reqList.get(0).getHour());
                serviceRow2.setText(reqList.get(0).getService());

                Button submit = findViewById(R.id.finalizeButton_r7);
                submit.setVisibility(View.VISIBLE);

            }
            else if(loopCounter == 2){
                SecondRow.setVisibility(View.VISIBLE);
                ThirdRow.setVisibility(View.VISIBLE);


                nameRow2.setText(reqList.get(0).getPatientName());
                wantedTimeRow2.setText(reqList.get(0).getHour());
                serviceRow2.setText(reqList.get(0).getService());

                nameRow3.setText(reqList.get(1).getPatientName());
                wantedTimeRow3.setText(reqList.get(1).getHour());
                serviceRow3.setText(reqList.get(1).getService());

                Button submit = findViewById(R.id.finalizeButton_r7);
                submit.setVisibility(View.VISIBLE);

            } else if (loopCounter >= 3) {
                SecondRow.setVisibility(View.VISIBLE);
                ThirdRow.setVisibility(View.VISIBLE);
                ForthRow.setVisibility(View.VISIBLE);


                nameRow2.setText(reqList.get(0).getPatientName());
                wantedTimeRow2.setText(reqList.get(0).getHour());
                serviceRow2.setText(reqList.get(0).getService());

                nameRow3.setText(reqList.get(1).getPatientName());
                wantedTimeRow3.setText(reqList.get(1).getHour());
                serviceRow3.setText(reqList.get(1).getService());

                nameRow4.setText(reqList.get(2).getPatientName());
                wantedTimeRow4.setText(reqList.get(2).getHour());
                serviceRow4.setText(reqList.get(2).getService());

                if(loopCounter> 3){
                    Button next = findViewById(R.id.nextButton);
                    next.setVisibility(View.VISIBLE);
                }
                else if(loopCounter == 3){
                    Button submit = findViewById(R.id.finalizeButton_r7);
                    submit.setVisibility(View.VISIBLE);
                }
                loopCounter = 3;

            }
            notUsed = false;
        }
    }

    public void OnClickSubmit(View view){
        CheckBox checkBox2 = findViewById(R.id.checkBoxSecondRow_R7);
        CheckBox checkBox3 = findViewById(R.id.checkBoxThirdRow_R7);
        CheckBox checkBox4 = findViewById(R.id.checkBoxForthRow_R7);

        TableRow tb1 = findViewById(R.id.SecondRow_R7);
        TableRow tb2 = findViewById(R.id.ThirdRow_R7);
        TableRow tb3 = findViewById(R.id.ForthRow_R7);

        if (tb3.getVisibility() ==  View.VISIBLE){
            appointmentChecked.add(checkBox2.isChecked());
//            checkBox2.setChecked(false);

            appointmentChecked.add(checkBox3.isChecked());
            checkBox3.setChecked(false);

            appointmentChecked.add(checkBox4.isChecked());
            checkBox4.setChecked(false);
        }
        else if (tb2.getVisibility() ==  View.VISIBLE){
            appointmentChecked.add(checkBox2.isChecked());
//            checkBox2.setChecked(false);

            appointmentChecked.add(checkBox3.isChecked());
            checkBox3.setChecked(false);
        }else if (tb1.getVisibility() ==  View.VISIBLE){
            appointmentChecked.add(checkBox2.isChecked());
//            checkBox2.setChecked(false);
        }

        for(int i = 0; i < appointmentChecked.size();i++){

            if (appointmentChecked.get(i)){
                reqList.get(i).setChecked(true);
            }
        }

        for(Appointment_R7 ap:reqList){
            System.out.println("Out aDate: "+ap.getDate());
            System.out.println("Out Ckecked: "+ap.isChecked());
            if (ap.isChecked()){
                System.out.println("aDate: "+ap.getDate());
                OkHttpSender ok = new OkHttpSender(myIP,ap.getId(),ap.getDate());
            }
        }

        Intent intent = new Intent(this, Doctor_Options.class);
        startActivity(intent);
    }
}