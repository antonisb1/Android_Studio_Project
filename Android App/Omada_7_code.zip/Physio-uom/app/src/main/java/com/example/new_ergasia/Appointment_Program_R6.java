package com.example.new_ergasia;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Appointment_Program_R6 extends AppCompatActivity {
    private DatePickerDialog datePickerDialog;
    private Button dateButton;
    // OkHttpHandler handler;
    Handler_R6 handler;


    private ArrayList<TableRow> rowList;

    private TableLayout tableLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment_program_r6);

        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        initDatePicker();
        dateButton = findViewById(R.id.r6_datePickerButton);
        dateButton.setText(getTodaysDate());

        tableLayout = (TableLayout)findViewById(R.id.r6_table);
        rowList = new ArrayList<>();

        handler = new Handler_R6();
        handler.fetchDataFromPhpFile();
    }

    private String getTodaysDate()
    {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        month = month + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
        return makeDateString(day, month, year);
    }

    private void initDatePicker()
    {
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener()
        {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day)
            {
                month = month + 1;
                String date = makeDateString(day, month, year);
                dateButton.setText(date);
                displayData(handler.getHours(),handler.getDates(),handler.getPatientNames(),handler.getAppointmentDescriptions(),handler.getAvailabilities(),day,month,year);
            }
        };

        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);

        int style = AlertDialog.THEME_HOLO_LIGHT;

        datePickerDialog = new DatePickerDialog(this, style, dateSetListener, year, month, day);

    }

    private String makeDateString(int day, int month, int year)
    {
        return getMonthFormat(month) + " " + day + " " + year;
    }

    private String getMonthFormat(int month)
    {
        if(month == 1)
            return "JAN";
        if(month == 2)
            return "FEB";
        if(month == 3)
            return "MAR";
        if(month == 4)
            return "APR";
        if(month == 5)
            return "MAY";
        if(month == 6)
            return "JUN";
        if(month == 7)
            return "JUL";
        if(month == 8)
            return "AUG";
        if(month == 9)
            return "SEP";
        if(month == 10)
            return "OCT";
        if(month == 11)
            return "NOV";
        if(month == 12)
            return "DEC";

        //default should never happen
        return "JAN";
    }

    private void displayData(List<String> time, List<String> dates, List<String> pName, List<String> description, List<String> availabilities, int day, int month, int year){

        // Get the number of child views in the TableLayout to clear the table
        int childCount = tableLayout.getChildCount();

        // Iterate over the child views starting from the second row
        for (int i = childCount - 1; i > 0; i--) {
            View childView = tableLayout.getChildAt(i);
            tableLayout.removeView(childView);
        }

        for (int i = 0; i < time.size(); i++) {

            int splittedDate[] = splitDate(dates.get(i));
            if(splittedDate[0] == day && splittedDate[1] == month && splittedDate[2] == year && availabilities.get(i).equals("0")){


                int rowId = View.generateViewId();
                TableRow row = new TableRow(this);
                row.setId(rowId);
                // Set layout parameters for TableRow
                TableLayout.LayoutParams rowParams = new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, getResources().getDimensionPixelSize(R.dimen.row_height));
                rowParams.setMargins(0, 0, 0, 10);

                // Set background for TableRow
                row.setBackgroundResource(R.drawable.r6_border_white);

                // Create TextViews for each column
                TextView timeTextView = new TextView(this);
                timeTextView.setText(time.get(i));
                setTextView(timeTextView,(float)0.2);


                TextView pNameTextView = new TextView(this);
                pNameTextView.setText(pName.get(i));
                setTextView(pNameTextView,(float)0.5);


                TextView descriptionTextView = new TextView(this);
                descriptionTextView.setText(description.get(i));
                setTextView(descriptionTextView,(float)0.3);



                // Add TextViews to the row
                row.addView(timeTextView);
                row.addView(pNameTextView);
                row.addView(descriptionTextView);

                // Add the row to the table layout
                rowList.add(row);
                tableLayout.addView(row);
                tableLayout.requestLayout();
            }
        }
    }

    private void setTextView(TextView textView, float weight){
        // Generate a unique ID for the TextView
        int textViewId = View.generateViewId();

        // Set the generated ID to the TextView
        textView.setId(textViewId);

        TableRow.LayoutParams params = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT);
        params.weight = weight;
        params.gravity = Gravity.CENTER;
        params.setMargins(0, 0, 0, 0);

        textView.setBackgroundResource(R.drawable.r6_border_white);
        textView.setPadding(30, 10, 0, 10);
        textView.setTextColor(getResources().getColor(R.color.black));

        // Apply layout parameters to TextView
        textView.setLayoutParams(params);
    }




    private int[] splitDate(String dateString) {
        String[] components = dateString.split("-");

        if (components.length == 3) {
            int year = Integer.parseInt(components[0]);
            int month = Integer.parseInt(components[1]);
            int day = Integer.parseInt(components[2]);

            int[] result = {day, month, year};
            //System.out.println(result[0]+"-"+result[1]+"-"+result[2]);
            return result;
        } else {
            throw new IllegalArgumentException("Invalid date format.");
        }
    }
    public void openDatePicker(View view)
    {
        datePickerDialog.show();
    }
}